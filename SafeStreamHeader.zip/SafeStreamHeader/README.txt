Safe Stream Header 1.2.0

Purpose:
- Local-only declarative header modification.
- Configured only for:
  https://stream.biomaze.ir/*
  https://stream.titanmates.com/*
  https://stream.alphaschool.ir/*

Security design:
- No cookies permission.
- No history permission.
- No tabs permission.
- No webRequest permission.
- No downloads permission.
- No content scripts.
- No fetch/XHR code.
- No analytics/telemetry endpoint.
- No remote JavaScript.
- No storage of browsing history.

Header behavior:
- On biomaze requests, sets Referer to https://stream.biomaze.ir/
- On titanmates requests, sets Referer to https://stream.titanmates.com/
- On alphaschool requests, sets Referer to https://stream.alphaschool.ir/

Important:
This extension does not hide the user's IP address. The destination website can still see the public IP of the network connection. Use only on services/content where you are authorized to use the requested access method.
